package com.cz.demo;

import org.springframework.stereotype.Component;

@Component
public class Greet {
	public String hello()
	{
		return "Hello There!!";
	}
}
