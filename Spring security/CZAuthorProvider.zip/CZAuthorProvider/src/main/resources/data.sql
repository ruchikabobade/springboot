insert into author(id,name,genre,port)
values(10001,'ABC','Adventure',1);
insert into author(id,name,genre,port)
values(10002,'PQR','Suspense',2);
insert into author(id,name,genre,port)
values(10003,'XYZ','History',1);