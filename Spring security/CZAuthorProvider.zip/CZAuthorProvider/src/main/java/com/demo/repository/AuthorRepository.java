package com.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;


import com.demo.model.Author;

public interface AuthorRepository extends JpaRepository<Author, Integer>{
	public List<Author> findByGenre(String genre);
}
