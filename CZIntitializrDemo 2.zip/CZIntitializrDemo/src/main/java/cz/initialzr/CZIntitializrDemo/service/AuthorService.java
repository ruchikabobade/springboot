package cz.initialzr.CZIntitializrDemo.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.springframework.stereotype.Service;

import cz.initialzr.CZIntitializrDemo.model.Author;

@Service
public class AuthorService {

	private List<Author> authors = new ArrayList<>( Arrays.asList(
			new Author(11,"Shalini123","Suspense"),
			new Author(21,"Meera4554","Comedy"),
			new Author(31 ,"Pankaj53","Adventure")
		));
	public List<Author> getAllAuthors()
	{
		return this.authors;
	}
	public Author getAuthor(int id) {
		return authors.stream().filter(t -> t.getId()==(id)).findFirst().get();
	}		
		public void addAuthor(Author author)
		{
			authors.add(author);
		}
		public void updateAuthor(Author topic,int id)
		{
			for(int i=0;i<authors.size();i++)
			{
				Author t=authors.get(i);
				if(t.getId()==id)
				{
					authors.set(i, topic);
					break;
				}
			}

		}
		public void deleteAuthor(int id)
		{
			authors.removeIf(t->t.getId()==(id));

		}
}
